#include <iostream>
#include <vector>
#include <cstdlib>
#include <sys/time.h>
#include <stdio.h>
#include <limits>
using namespace std;

int main()
{
	int n=4096;
	
	vector<vector<float> > matrix_A(n, vector<float> (n, 0));
	vector<vector<float> > matrix_B(n, vector<float> (n, 0));
	vector<vector<float> > ANS(n, vector<float> (n, 0));
	struct timeval start_time,stop_time;
	double time_spent = 0.0;
	//cout<<<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			matrix_A[i][j]=rand() / (float)1147483648;
			matrix_B[i][j]=rand() / (float)1147483648;
			//cout<<"hello"<<endl;
		} 
	}
	//clock_t begin = clock();
	gettimeofday(&start_time, NULL);
	//matrix mul
	for(int i=0;i<n;i++)    
	{    
		for(int j=0;j<n;j++)    
		{    
		ANS[i][j]=0;    
			for(int k=0;k<n;k++)    
			{    
			ANS[i][j]+=matrix_A[i][k]*matrix_B[k][j];    
			}    
		}    
	} 
	/*
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix_A[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix_B[i][j]<<" ";
		} 
		cout<<endl;
	} 
	cout<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<ANS[i][j]<<" ";
		} 
		cout<<endl;
	} 
	*/

	//find min and index
	float min=numeric_limits<float>::max();
	int min_row=0,min_column=0;
	for(int i=0;i<n;i++)    
	{    
		for(int j=0;j<n;j++)    
		{    
			if(min>ANS[i][j])
			{
				min=ANS[i][j];
				min_row=i;
				min_column=j;
			}
		}    
	} 
	gettimeofday(&stop_time, NULL);	

	
	//clock_t end = clock();	
	//time_spent += (double)(end - begin) / CLOCKS_PER_SEC;
	//printf("Time elpased is %f seconds\n", time_spent);
	printf("Time taken is : %ld  seconds\n",stop_time.tv_sec - start_time.tv_sec);
	printf("min is %f \n", min);
	printf("min row is %d \n", min_row);
	printf("min column is %d \n", min_column);
	//time_t elapsed = start_time - stop_time;
    

    
    //printf("Time measured: %f seconds.\n", (double)elapsed);
	return 0;
}