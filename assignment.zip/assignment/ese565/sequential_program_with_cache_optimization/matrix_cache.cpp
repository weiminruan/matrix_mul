#include <iostream>
#include <vector>
#include <cstdlib>
#include <sys/time.h>
#include <stdio.h>
#include <limits>
using namespace std;
const int n=4096;
void print_matrix(int n,vector<vector<float> > matrix)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
}
int main()
{
	
	vector<vector<float> > matrix_A(n, vector<float> (n, 0));
	vector<vector<float> > matrix_B(n, vector<float> (n, 0));
	vector<vector<float> > ANS(n, vector<float> (n, 0));
	struct timeval start_time,stop_time;
	//srand (static_cast <unsigned> (time(0)));
	//cout<<<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			matrix_A[i][j]=((float) rand()) / (float)1147483648;
			matrix_B[i][j]=((float) rand()) / (float)1147483648;
		} 
	}
	//print_matrix(n,matrix_A);
	//print_matrix(n,matrix_B);
	//inverse
	gettimeofday(&start_time, NULL);	
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
			float temp=matrix_B[i][j];
			matrix_B[i][j]=matrix_B[j][i];
			matrix_B[j][i]=temp;
		} 
	}

	
	//after transpose
	//print_matrix(n,matrix_B);
	
	//matrix mul
	for(int i=0;i<n;i++)    
	{    
		for(int j=0;j<n;j++)    
		{    
		ANS[i][j]=0;    
			for(int k=0;k<n;k++)    
			{    
			ANS[i][j]+=matrix_A[i][k]*matrix_B[j][k];    
			}    
		}    
	} 
	//print_matrix(n,ANS);
	//find min and index
	float min=numeric_limits<float>::max();
	int min_row=0,min_column=0;
	for(int i=0;i<n;i++)    
	{    
		for(int j=0;j<n;j++)    
		{    
			if(min>ANS[i][j])
			{
				min=ANS[i][j];
				min_row=i;
				min_column=j;
			}
		}    
	} 
	gettimeofday(&stop_time, NULL);	
	long seconds = stop_time.tv_sec - start_time.tv_sec;
	long microseconds = stop_time.tv_usec - start_time.tv_usec;
 	double elapsed = seconds + microseconds*1e-6;
 	printf("Time measured: %.3f seconds.\n", elapsed);
	printf("array size is %d*%d \n", n,n);
	//printf("Time elpased is %f seconds\n", time_spent);

	printf("min is %f \n", min);
	printf("min row is %d \n", min_row);
	printf("min column is %d \n", min_column);
	//time_t elapsed = start_time - stop_time;
    

    
    //printf("Time measured: %f seconds.\n", (double)elapsed);
	return 0;
}
