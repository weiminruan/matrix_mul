#include <iostream>
#include <vector>
#include <cstdlib>
#include <sys/time.h>
#include <stdio.h>
#include <limits>
#include <stdlib.h>
#include <assert.h>
#include "matrix_mul_ispc.h"
const char* thread=getenv("OMP_NUM_THREADS");
using namespace std;
using namespace ispc;
const int n=4096;

void print_matrix(int n,vector<vector<float> > matrix)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
}
void print_matrix(float matrix[][n]) 
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
}
void print_matrix_1d(vector<int> matrix) 
{

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i*n+j]<<" ";
		}
		cout<<endl;
	}
}
void print_matrix_1d(vector<float> matrix) 
{

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i*n+j]<<" ";
		}
		cout<<endl;
	}
}
void reduce_dimension(vector<vector<float> > matrix_B,vector<float> &B)
{
	for(int i=0;i<matrix_B.size();i++)
	{
		for(int j=0;j<matrix_B[0].size();j++)
		{
			B.push_back(matrix_B[i][j]);
		}
	}
}
int main()
{
	int number_of_thread=stoi(thread);
	cout<<number_of_thread<<endl;
	struct timeval start_time,stop_time;
	vector<vector<float> > matrix_A(n, vector<float> (n, 0));
	vector<vector<float> > matrix_B(n, vector<float> (n, 0));
	//vector<vector<float> > ANS(n, vector<float> (n, 0));
	//float * foo;
	//foo = new float [n*n];
	vector<float> A;
	vector<float> B;
	vector<float> ANSWER(vector<float> (n*n, 0));
	vector<int> column(vector<int> (number_of_thread, 0));
	vector<int> row(vector<int> (number_of_thread, 0));
	vector<float> min_val(vector<float> (number_of_thread, 0));
	float result[1];
	int min_index[1];
	int index[number_of_thread];
	int job[number_of_thread];

	//srand (static_cast <unsigned> (time(0)));
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			matrix_A[i][j]=rand()/(float)1147483648 ;
			matrix_B[i][j]=rand()/(float)1147483648 ;

			//matrix_A[i][j]=((float) rand());
			//matrix_B[i][j]=((float) rand());
		} 
	}
	//print_matrix(n,matrix_A);
	//print_matrix(n,matrix_B);
	//inverse
	gettimeofday(&start_time, NULL);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
			float temp=matrix_B[i][j];
			matrix_B[i][j]=matrix_B[j][i];
			matrix_B[j][i]=temp;
		} 
	}
	//print_matrix(n,matrix_B);	
	reduce_dimension(matrix_A,A);
	reduce_dimension(matrix_B,B);
	//print_matrix_1d(A);
	//cout<<endl;
	//print_matrix_1d(B);
	//cout<<endl;
	//after transpose
	
	//matrix mul

	if(n%number_of_thread==0)//can equally partition the problem to smaller pieces
	{
		for(int i=0;i<number_of_thread;i++)
		{
			//int mod=i%n;  
			//int location=i/n;
			job[i]=n/number_of_thread;
			index[i]=i*n/number_of_thread;
		}
	}
	else //need to assign more works to some threads
	{
		int each_thread=n/number_of_thread;
		int count=0;
		for(int i=0;i<number_of_thread;i++)
		{ 
			int temp=count;
			for(int j=0;j<each_thread;j++)
			{
				//data.id.push_back(count);
				count=count+1;
			}
			if(n%number_of_thread>=i+1)
			{
				//data.id.push_back(count);
				count=count+1;
			}
			job[i]=count-temp;
			index[i]=temp;

		}
	}
	/*
	for(int i=0;i<number_of_thread;i++)
	{
		cout<<job[i]<<endl;
		cout<<index[i]<<endl;
	}
	*/

		
	matrix_mul_fun_withTasks(number_of_thread,n,&job[0],&index[0],&A[0],&B[0],&ANSWER[0]);
	min_func_withTasks(number_of_thread,n,&ANSWER[0],&min_val[0],&row[0],&column[0],&job[0],&index[0]);
	find_mini(number_of_thread,&min_val[0],&result[0],&min_index[0]);
	//print_matrix_1d(ANSWER);
	//
	//cout<<"answer matrix!!!!"<<endl;
	//print_matrix(n,ANS);
	//find min and index
	/*
	float min=numeric_limits<float>::max();
	
	//reduce_dimension(ANS,ANSWER);
		
	partial_sum(n,min,&ANSWER[0],&partial[0],&column[0]);
	//find_min(min,&ANSWER[0],min_row,min_column);
	int min_row=0;
	int min_column=0;

	
	for(int i=0;i<n;i++)    
	{    
		if(min>partial[i])
		{
			min=partial[i];
			min_row=i;
			min_column=column[i];
		}
	} 
	*/
	gettimeofday(&stop_time, NULL);	
	//print_matrix_1d(ANSWER);
	//print_matrix(n,ANS);
 long seconds = stop_time.tv_sec - start_time.tv_sec;
 long microseconds = stop_time.tv_usec - start_time.tv_usec;
 double elapsed = seconds + microseconds*1e-6;
 printf("Time measured: %.3f seconds.\n", elapsed);
	//printf("Time taken is : %ld  seconds. %ld microsecond \n",stop_time.tv_sec - start_time.tv_sec,stop_time.tv_usec - start_time.tv_usec);
	printf("min is %f \n", result[0]);
	printf("min row is %d \n", row[min_index[0]]);
	printf("min column is %d \n", column[min_index[0]]);
	
	return 0;
}
