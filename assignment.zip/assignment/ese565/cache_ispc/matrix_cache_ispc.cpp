#include <iostream>
#include <vector>
#include <cstdlib>
#include <sys/time.h>
#include <stdio.h>
#include <limits>
#include <stdlib.h>

#include "matrix_mul_ispc.h"
using namespace std;
using namespace ispc;
const int n=4096;

void print_matrix(int n,vector<vector<float> > matrix)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
}
void print_matrix(float matrix[][n]) 
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
}
void print_matrix_1d(vector<int> matrix) 
{

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i*n+j]<<" ";
		}
		cout<<endl;
	}
}
void print_matrix_1d(vector<float> matrix) 
{

	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i*n+j]<<" ";
		}
		cout<<endl;
	}
}
void reduce_dimension(vector<vector<float> > matrix_B,vector<float> &B)
{
	for(int i=0;i<matrix_B.size();i++)
	{
		for(int j=0;j<matrix_B[0].size();j++)
		{
			B.push_back(matrix_B[i][j]);
		}
	}
}
int main()
{
	vector<vector<float> > matrix_A(n, vector<float> (n, 0));
	vector<vector<float> > matrix_B(n, vector<float> (n, 0));
	//vector<vector<float> > ANS(n, vector<float> (n, 0));
	//float * foo;
	//foo = new float [n*n];
	vector<float> A;
	vector<float> B;
	vector<float> ANSWER(vector<float> (n*n, 0));
 	//result matrix
	//vector<float> ANSWER(vector<float> (n*n, 0));
	vector<int> column(vector<int> (n, 0));
	vector<float> partial(vector<float> (n, 0));
	struct timeval start_time,stop_time;
	//srand (static_cast <unsigned> (time(0)));
	//cout<<<<endl;
	float min=numeric_limits<float>::max();
	int min_row=0;
	int min_column=0;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			matrix_A[i][j]=rand()/(float)1147483648 ;
			matrix_B[i][j]=rand()/(float)1147483648 ;
		} 
	}
	//print_matrix(n,matrix_A);
	//print_matrix(n,matrix_B);
	//inverse

	gettimeofday(&start_time, NULL);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
			float temp=matrix_B[i][j];
			matrix_B[i][j]=matrix_B[j][i];
			matrix_B[j][i]=temp;
		} 
	}
	//print_matrix(n,matrix_B);	
	//reduce_dimension(matrix_A,A);
	reduce_dimension(matrix_B,B);
	//print_matrix_1d(A);
	//print_matrix_1d(B);
	//after transpose
	
	//matrix mul
	
	for(int i=0;i<n;i++)    
	{    
		matrix_mul(n,i,&matrix_A[i][0],&B[0],&ANSWER[i*n]);
	} 
	//print_matrix(n,ANS);
	
	//matrix_mul_2(n,&A[0],&B[0],&ANSWER[0],&test_1[0],&test_2[0]);
	//matrix_mul_2(n,&A[0],&B[0],&ANSWER[0]);
	
	//print_matrix_1d(test_1);
	//print_matrix_1d(test_2);
	//print_matrix_1d(ANSWER);
	//
	//cout<<"answer matrix!!!!"<<endl;
	//print_matrix(n,ANS);
	//find min and index
	
	
	
	//reduce_dimension(ANS,ANSWER);
		
	partial_sum(n,min,&ANSWER[0],&partial[0],&column[0]);
	
	/*
	for(int i=0;i<n;i++)    
	{    
		for(int j=0;j<n;j++)    
		{    
			if(min>ANS[i][j])
			{
				min=ANS[i][j];
				min_row=i;
				min_column=j;
			}
		} 
	} 
	*/
	///*
	
	for(int i=0;i<n;i++)    
	{    
		if(min>partial[i])
		{
			min=partial[i];
			min_row=i;
			min_column=column[i];
		}
	} 
	
	/*
	for(int i=0;i<n*n;i++)    
	{    
		if(min>ANSWER[i])
		{
			min=ANSWER[i];
			//min_row=i;
			//min_column=column[i];
		}
	} 
	*/
	//*/
	
	gettimeofday(&stop_time, NULL);	
	//print_matrix_1d(ANSWER);
	//print_matrix(n,ANS);
	long seconds = stop_time.tv_sec - start_time.tv_sec;
	long microseconds = stop_time.tv_usec - start_time.tv_usec;
 	double elapsed = seconds + microseconds*1e-6;
 	printf("Time measured: %.3f seconds.\n", elapsed);
	printf("array size is %d*%d \n", n,n);
	printf("min is %f \n", min);
	printf("min row is %d \n", min_row);
	printf("min column is %d \n", min_column);
	
	return 0;
}
