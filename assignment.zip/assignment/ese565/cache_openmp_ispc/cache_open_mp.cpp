#include <iostream>
#include <vector>
#include <cstdlib>
#include <sys/time.h>
#include <stdio.h>
#include <limits>
#include <vector>
#include <assert.h>
#include <omp.h>
#include "matrix_mul_ispc.h"
using namespace std;
using namespace ispc;
const int n=4096;
const char* thread=getenv("OMP_NUM_THREADS");
const int number_of_thread=stoi(thread);
const int total=n*n;
typedef struct{
	vector<vector<float> >* A;
	vector<vector<float> >* B;
	vector<int> id;
	vector<vector<float> > ANS;   
	vector<int> min_row;
	vector<int> min_column;
	vector<float> min_value;
}matrix;


void print_matrix(int n,vector<vector<float> > matrix)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
}
void reduce_dimension(vector<vector<float> > matrix_B,vector<float> &B)
{
	for(int i=0;i<matrix_B.size();i++)
	{
		for(int j=0;j<matrix_B[0].size();j++)
		{
			B.push_back(matrix_B[i][j]);
		}
	}
}
int main()
{
	omp_set_nested(1);
	cout<<number_of_thread<<endl;
	//cout<<"hello"<<endl;
	
	struct timeval start_time,stop_time;
	vector<vector<float> > matrix_A(n, vector<float> (n, 0));
	vector<vector<float> > matrix_B(n, vector<float> (n, 0));
	//vector<vector<vector<float>> > ANS(n,vector<vector<float>> (n, vector<float> (16, 0)));
	vector<vector<float> > ANS(n, vector<float> (n, 0));
	vector<float> B;
	double time_spent = 0.0;
	//srand (static_cast <unsigned> (time(0)));
	//cout<<<<endl;
	float min_arr[n];
	int min_row_arr[n];
	int min_column_arr[n];
	float mini=numeric_limits<float>::max();
	int min_column;
	int min_row;
	int index[1];
	float min_val[1];
	
	omp_set_num_threads(number_of_thread);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			//matrix_A[i][j]=((float) rand());
			//matrix_B[i][j]=((float) rand());
			matrix_A[i][j]=rand() / (float)1147483648;
			matrix_B[i][j]=rand() / (float)1147483648;
			//matrix_A[i][j]=((float) rand()) / (float) RAND_MAX;
			//matrix_B[i][j]=((float) rand()) / (float) RAND_MAX;
		} 
	}
	//print_matrix(n,matrix_A);
	//print_matrix(n,matrix_B);
	//inverse
	gettimeofday(&start_time, NULL);	
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
			float temp=matrix_B[i][j];
			matrix_B[i][j]=matrix_B[j][i];
			matrix_B[j][i]=temp;
		} 
	}
	reduce_dimension(matrix_B,B);
	//after transpose

	#pragma omp parallel for
	
	for(int i=0;i<n;i++)
	{
		matrix_mul(n,i,&matrix_A[i][0],&B[0],&ANS[i][0]);

	}

	//print_matrix(n,ANS);
	/*
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			ANS_1d.push_back(ANS[i][j]);
		}
	}
	*/
	//int min_column;
	
	#pragma omp parallel for 
	for(int i=0;i<n;i++) 
	{
		int min_column[1];
		float min_val[1];
		//#pragma omp parallel for reduction(min:min_val)
		minimumValueOffset(&ANS[i][0],&min_val[0],&min_column[0],n);
		min_arr[i]=min_val[0];
		//cout<<min_val<<endl;
		min_row_arr[i]=i;
		min_column_arr[i]=min_column[0];

	}
	/*
	for(int i=0;i<n;i++)
	{
		cout<<min_arr[i]<<endl;
		cout<<min_row_arr[i]<<endl;
		cout<<min_column_arr[i]<<endl;	
		cout<<endl;
	}
	*/
	minimumValueOffset(&min_arr[0],&min_val[0],&index[0],n);
	/*
	mini=numeric_limits<float>::max();
	int target=0;
	//float min_val=numeric_limits<float>::max();
	//#pragma omp parallel for reduction(min:mini)
	for(j=0;j<n;j++)
	{
		if(mini>min_arr[j])
		{
			mini=min_arr[j];
			target=j;
		}
	}	
	*/
	gettimeofday(&stop_time, NULL);	
	//cout<<"target is "<<target<<endl;
	min_row=min_row_arr[index[0]];
	min_column=min_column_arr[index[0]];
	
	//print_matrix(n,ANS);
	
	//float min=numeric_limits<float>::max();;
	//int min_row=0;
	//int min_column=0;
	long seconds = stop_time.tv_sec - start_time.tv_sec;
	long microseconds = stop_time.tv_usec - start_time.tv_usec;
 	double elapsed = seconds + microseconds*1e-6;
 	printf("Time measured: %.3f seconds.\n", elapsed);
	
	printf("array size is %d*%d \n", n,n);
	//printf("Time taken is : %ld  seconds\n",stop_time.tv_sec - start_time.tv_sec);
	printf("min is %f \n", min_val[0]);
	printf("min row is %d \n", min_row);
	printf("min column is %d \n", min_column);
	
	
	return 0;
}
