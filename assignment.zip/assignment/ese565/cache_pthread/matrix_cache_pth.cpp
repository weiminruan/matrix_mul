#include <iostream>
#include <vector>
#include <cstdlib>
#include <sys/time.h>
#include <stdio.h>
#include <pthread.h>
#include <limits>
#include <vector>
#include <assert.h>
using namespace std;
const int n=4096;
const char* thread=getenv("OMP_NUM_THREADS");
const int number_of_thread=stoi(thread);
const int total=n*n;
typedef struct{
	vector<vector<float> >* A;
	vector<vector<float> >* B;
	vector<int> id;
	vector<vector<float> > ANS;   
	vector<int> min_row;
	vector<int> min_column;
	vector<float> min_value;
}matrix;
void *matrix_mul(void *args)
 {
    matrix* thread_data=(matrix*) args;
    //cout<<"hello"<<endl;
    //cout<<(*thread_data->A)[0][0];
    //cout<<(*thread_data->A)[0][0]<<endl;
    for(int i=0;i<thread_data->id.size();i++) //each row
    {
    	vector<float> TEMP;
    	
    	for(int j=0;j<n;j++)
	    {
	    	float value=0;
	    	for(int k=0;k<n;k++)
	    	{
				value+=(*thread_data->A)[thread_data->id[i]][k]*(*thread_data->B)[j][k];
				//value+=thread_data->A[thread_data->id[i]][k]*thread_data->B[j][k];
	    	}
	    	TEMP.push_back(value);
	    }
	    thread_data->ANS.push_back(TEMP);
	    //find minimum
	    
	    float MIN=numeric_limits<float>::max();
	    int temp_min_column=0;
	    for(int j=0;j<n;j++)
	    {
	    	if(TEMP[j]<MIN)
	    	{
	    		MIN=TEMP[j];
	    		temp_min_column=j;
	    	}
	    }
	    thread_data->min_row.push_back(thread_data->id[i]);
	    thread_data->min_value.push_back(MIN);
	    thread_data->min_column.push_back(temp_min_column);
    }
    pthread_exit(NULL);  

 }
void print_matrix(int n,vector<vector<float> > matrix)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<matrix[i][j]<<" ";
		} 
		cout<<endl;
	}
	cout<<endl;
}
int main()
{

	cout<<number_of_thread<<endl;
	//cout<<"hello"<<endl;
	
	struct timeval start_time,stop_time;
	vector<vector<float> > matrix_A(n, vector<float> (n, 0));
	vector<vector<float> > matrix_B(n, vector<float> (n, 0));
	vector<vector<float> > ANS(n, vector<float> (n, 0));

	double time_spent = 0.0;
	//srand (static_cast <unsigned> (time(0)));
	//cout<<<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			//matrix_A[i][j]=((float) rand());
			//matrix_B[i][j]=((float) rand());

			matrix_A[i][j]= rand()/ (float) 1147483648;
			matrix_B[i][j]= rand()/ (float) 1147483648;
		} 
	}
	//print_matrix(n,matrix_A);
	//print_matrix(n,matrix_B);
	//inverse
	vector<matrix> data_matrix;
	pthread_t threads[number_of_thread];
	float min=numeric_limits<float>::max();;
	int min_row=0;
	int min_column=0;
	gettimeofday(&start_time, NULL);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
			float temp=matrix_B[i][j];
			matrix_B[i][j]=matrix_B[j][i];
			matrix_B[j][i]=temp;
		} 
	}
	//after transpose
	//print_matrix(n,matrix_B);
	
	//data.B=matrix_B;
	//data.ANS=ANS;
	
	
	if(n%number_of_thread==0)//can equally partition the problem to smaller pieces
	{
		for(int i=0;i<number_of_thread;i++)
		{
			matrix data;
			int mod=i%n;
			int location=i/n;
			data.A=&matrix_A;
			data.B=&matrix_B;//need to change to reference 
			for(int j=0;j<n/number_of_thread;j++)
			{
				data.id.push_back(j+i*(n/number_of_thread));
			}

			data_matrix.push_back(data);
		}
	}
	else //need to assign more works to some threads
	{
		int each_thread=n/number_of_thread;
		//cout<<each_thread<<endl;
	//	cout<<endl;
		int count=0;
		for(int i=0;i<number_of_thread;i++)
		{
			matrix data;
			data.A=&matrix_A;
			data.B=&matrix_B;//need to change to reference 
			for(int j=0;j<each_thread;j++)
			{
				data.id.push_back(count);
				count=count+1;
			}
			if(n%number_of_thread>=i+1)
			{
				data.id.push_back(count);
				count=count+1;
			}
			data_matrix.push_back(data);
		}
	}

	
	
	for(int i=0; i<number_of_thread; i++)
	{
	   //printf("In main: creating thread %ld\n", i);
	   pthread_create(&threads[i], NULL, matrix_mul,(void*)&data_matrix[i]);
	}
	for(int i=0; i<number_of_thread; i++){
	   pthread_join(threads[i],NULL);
	}
	
	/*
	cout<<"ans matrix"<<endl;
	
	for(int i=0; i<data_matrix.size(); i++)
	{
		for(int j=0; j<data_matrix[i].ANS.size(); j++)
		{
			for(int k=0; k<data_matrix[i].ANS[0].size(); k++)
			{
				cout<<data_matrix[i].ANS[j][k]<<" ";
			}
			cout<<endl;
		}
	}
	*/
	
	
	for(int i=0; i<data_matrix.size(); i++)
	{
		for(int j=0; j<data_matrix[i].min_value.size(); j++)
		{
			//cout<<data_matrix[i].min_value[j]<<endl;
			
			if(min>data_matrix[i].min_value[j])
			{
				min=data_matrix[i].min_value[j];
				min_row=data_matrix[i].min_row[j];
				min_column=data_matrix[i].min_column[j];
			}
			
		}
	}
	gettimeofday(&stop_time, NULL);	
	long seconds = stop_time.tv_sec - start_time.tv_sec;
	long microseconds = stop_time.tv_usec - start_time.tv_usec;
	double elapsed = seconds + microseconds*1e-6;
	printf("Time measured: %.3f seconds.\n", elapsed);
	printf("array size is %d*%d \n", n,n);
	//printf("Time taken is : %ld  seconds\n",stop_time.tv_sec - start_time.tv_sec);
	printf("min is %f \n", min);
	printf("min row is %d \n", min_row);
	printf("min column is %d \n", min_column);
	pthread_exit(NULL);
	
	return 0;
}
